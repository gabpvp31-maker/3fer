# Créditos

## Código e bibliotecas

- Three.js r128, GLTFLoader e SkeletonUtils: autores de Three.js, licença MIT.
  https://github.com/mrdoob/three.js/tree/r128
- Texto da licença: https://github.com/mrdoob/three.js/blob/r128/LICENSE

## Modelos incorporados ao jogo

- **Soldier**: personagem e animações de Mixamo, distribuídos no exemplo oficial
  `webgl_animation_skinning_blending` de Three.js. Usado como personagem
  animado, com materiais ajustados para o cenário. Não é um modelo de Fallout.
  Origem: https://github.com/mrdoob/three.js/blob/dev/examples/models/gltf/Soldier.glb
  Condições de uso de Mixamo: https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html
- **Flight Helmet**, domínio público / CC0, conversão de Gary Hsu (2018),
  disponibilizado pelo catálogo glTF Sample Assets de Khronos. Texturas
  reduzidas para 512 px e geometria simplificada no Blender para este jogo.
  https://github.com/KhronosGroup/glTF-Sample-Assets/tree/main/Models/FlightHelmet

O código do pós-processamento, as ruínas, os mapas de superfície procedurais,
os elementos da estação, a modelagem das armas, o terminal R-07, a missão e
a sequência musical sintetizada foram criados para este projeto.
Não há modelos, trilha, falas ou texturas extraídos de Fallout.
