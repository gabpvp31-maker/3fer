# Último Refúgio — Estação 07

RPG de sobrevivência em primeira pessoa, com estética retrofuturista e
recursos incorporados ao HTML. O jogo funciona sem downloads durante a partida:
Three.js, plugins, modelos animados e texturas dos modelos estão no próprio arquivo.

Sirva `ultimo-refugio-sobrevivencia.html` por HTTP em um navegador desktop com WebGL.
Recomendado: teclado e mouse. O servidor local abaixo fornece um endereço estável
para o salvamento. A política do navegador gerenciado impede testar a abertura direta
por `file://`; a validação foi feita com HTTP local e sem acesso a serviços externos.

## Jogar

- **WASD / Shift:** mover e correr. Mouse mira; clique atira. **R** recarrega.
- **1 / 2 / 3:** pistola, escopeta e fuzil. **Q:** golpe; **T:** granada.
- **E:** conversar com Iara, vasculhar baús e ativar o retransmissor.
- **I:** terminal R-07: estado, atributos, inventário utilizável, missões,
  mapa com destino clicável, rádio e qualidade gráfica.
- **Tab:** S.A.T., combate assistido com tempo reduzido a 8%, seleção de
  alvo e região corporal. Cada disparo custa 25 PA e uma munição. Cobertura
  bloqueia o disparo; tiros nas pernas reduzem a mobilidade. Fora do modo,
  os PA se recuperam. Setas/A/D trocam alvo; Espaço/Enter executa o tiro.
- **C:** criação. **G / V / H / X:** comer, beber, curar e usar anti-rad.
- **F:** lanterna. **Esc:** fechar a interface atual ou pausar.

Fale com Iara no toldo laranja da estação. A missão **Sinal de esperança**
passa por coletar componentes, restaurar o rádio, defender o sinal e receber
uma recompensa. Há três baús próximos ao ponto de partida para iniciar a exploração.

## Gráficos e áudio

O jogo inclui fachadas quebradas com aberturas reais, ferragens, escombros,
posto de combustível, antena, torre d'água, materiais com normal/roughness maps,
pessoas com esqueleto animado e equipamento com texturas PBR. As armas têm
modelagem própria com bordas arredondadas, peças mecânicas e mãos com luvas.
O pós-processamento aplica suavização de bordas, brilho, granulação, cor e vinheta.

Em **I → Rádio**, escolha qualidade leve, equilibrada ou detalhada, desligue
os efeitos ou silencie o áudio. A rádio usa uma sequência musical original
sintetizada localmente. Os modelos e suas licenças estão em [CREDITS.md](CREDITS.md).

## Checkpoints

O checkpoint salva a cada 30 segundos, ao pausar e ao fechar a página, quando
há armazenamento local disponível. Guarda recursos, saúde, necessidades,
munição, dia, atributos, missões, construções e o progresso do rádio.
Uma defesa incompleta da estação reaparece ao continuar. A recompensa não se repete.

Continuar retorna ao acampamento, com cenário e baús renovados. Não é uma cópia
exata dos inimigos e objetos do mundo anterior. O progresso fica neste navegador
e neste endereço; mudar de origem ou limpar os dados não transfere o save.
Uma nova expedição substitui o progresso anterior; morrer encerra o checkpoint.

## Desenvolvimento na nuvem

```sh
python3 /workspace/cloud-setup/3fer/serve.py
```

O servidor lê o HTML do repositório. Não há backend nem compilação.
Os testes usam Chromium, Python e Playwright disponíveis no ambiente:

```sh
cd /workspace/3fer
python3 -m unittest discover -s tests -v
```

As decisões da expansão estão em [docs/rpg-plan.md](docs/rpg-plan.md).
