import test_game


class RPGTests(test_game.GameTests):
    # Keep the original suite in its own class, without duplicating its runs.
    test_pause_freezes_simulation_and_blocks_actions = None
    test_checkpoint_restores_progress_and_new_game_clears_it = None
    test_corrupt_save_does_not_break_new_game = None
    test_invalid_mission_in_checkpoint_is_rejected = None
    test_crafting_does_not_shoot_and_blur_pauses = None
    test_automatic_checkpoint_survives_reload = None

    def test_wrist_terminal_pauses_and_uses_real_inventory(self):
        self.start_game()
        self.page.keyboard.press('KeyI')
        self.assertTrue(self.page.locator('#wrist').is_visible(), 'I must open the wrist terminal')
        before = self.page.evaluate('tod')
        self.page.keyboard.down('KeyW')
        self.page.wait_for_timeout(250)
        self.page.keyboard.up('KeyW')
        self.assertEqual(before, self.page.evaluate('tod'))
        self.page.get_by_role('tab', name='Inventário', exact=True).click()
        self.page.evaluate('nd.f=30')
        self.page.get_by_role('button', name='Comer', exact=True).click()
        self.assertEqual(self.page.evaluate('[inv.food,nd.f]'), [1,65])
        self.page.keyboard.press('Escape')
        self.assertFalse(self.page.locator('#wrist').is_visible())
        self.assertEqual(self.errors, [])

    def test_map_destination_and_graphics_settings(self):
        self.start_game()
        self.page.keyboard.press('KeyI')
        self.page.get_by_role('tab', name='Mapa', exact=True).click()
        self.page.locator('#world-map').click(position={'x': 100, 'y': 100})
        self.assertTrue(self.page.evaluate('rpg.waypoint !== null && Number.isFinite(rpg.waypoint.x)'))
        self.page.get_by_role('tab', name='Rádio', exact=True).click()
        self.page.locator('#quality-setting').select_option('low')
        self.page.get_by_role('button', name='Efeitos: ligados', exact=True).click()
        self.assertEqual(self.page.evaluate('[graphics.quality,graphics.effects,R.shadowMap.enabled]'), ['low',False,False])
        self.page.reload(wait_until='networkidle')
        self.assertEqual(self.page.evaluate('[graphics.quality,graphics.effects]'), ['low',False])
        self.assertEqual(self.errors, [])

    def test_held_terminal_and_tactical_keys_do_not_toggle_repeatedly(self):
        self.start_game()
        self.page.keyboard.down('KeyI')
        self.page.keyboard.down('KeyI')
        self.assertTrue(self.page.locator('#wrist').is_visible())
        self.page.keyboard.up('KeyI')
        self.page.keyboard.press('Escape')
        self.page.evaluate("spawnEn('w');const e=En[En.length-1];e.g.position.set(0,H(0,-9),-9);e.v=0")
        self.page.keyboard.down('Tab')
        self.page.keyboard.down('Tab')
        self.assertTrue(self.page.locator('#aim-panel').is_visible())
        self.page.keyboard.up('Tab')
        self.assertEqual(self.errors, [])

    def test_map_click_matches_visible_coordinates_on_wide_screen(self):
        self.start_game()
        self.page.keyboard.press('KeyI')
        self.page.get_by_role('tab', name='Mapa', exact=True).click()
        position=self.page.locator('#world-map').evaluate('c=>{const r=c.getBoundingClientRect();return {x:r.width/2+Math.min(r.width,r.height*2)/4,y:r.height/2}}')
        self.page.locator('#world-map').click(position=position)
        self.assertAlmostEqual(self.page.evaluate('rpg.waypoint.x'),65,delta=1)
        self.assertAlmostEqual(self.page.evaluate('rpg.waypoint.z'),0,delta=1)
        self.assertEqual(self.errors, [])

    def test_detailed_models_and_post_pipeline_survive_resize(self):
        shader_errors = []
        self.page.on('console', lambda m: shader_errors.append(m.text) if m.type=='error' and 'WebGL' in m.text else None)
        self.page.wait_for_function('assetsReady')
        self.assertEqual(self.page.evaluate('assetFailures'), [])
        self.assertTrue(self.page.evaluate('trader.userData.detailed'))
        self.page.set_viewport_size({'width': 1100, 'height': 800})
        self.page.wait_for_function('postPipeline.frames > 1')
        self.assertTrue(self.page.evaluate('postPipeline.target.width === Math.floor(cv.width) && postPipeline.target.height === Math.floor(cv.height)'))
        self.assertEqual(shader_errors, [])
        self.assertEqual(self.errors, [])

    def test_assisted_shot_spends_ap_and_ammo_and_respects_cover(self):
        self.start_game()
        self.page.evaluate("spawnEn('w');const e=En[En.length-1];e.g.position.set(0,H(0,-9),-9);e.hp=100;e.v=0;P.x=0;P.z=4;yaw=0;pitch=0")
        self.page.keyboard.press('Tab')
        self.assertTrue(self.page.locator('#aim-panel').is_visible())
        self.page.get_by_role('button', name='Tronco', exact=False).click()
        self.page.get_by_role('button', name='Executar disparo', exact=True).click()
        self.assertEqual(self.page.evaluate('[Math.round(ap),mag[1]]'), [75,11])
        self.page.evaluate('walls.push({x:0,z:-2,hw:3,hd:1})')
        self.page.wait_for_function("document.getElementById('aim-fire').disabled")
        self.page.get_by_role('button', name='Executar disparo', exact=True).click(force=True)
        self.assertEqual(self.page.evaluate('[Math.round(ap),mag[1]]'), [75,11])
        self.page.keyboard.press('Escape')
        self.assertFalse(self.page.locator('#aim-panel').is_visible())
        self.assertEqual(self.errors, [])

    def test_dialogue_quest_reward_only_once_and_checkpoint_keeps_it(self):
        self.start_game()
        self.page.evaluate('P.x=TRD.x;P.z=TRD.z+2')
        self.page.wait_for_function("tgt && tgt.k==='trader'")
        self.page.keyboard.press('KeyE')
        self.assertTrue(self.page.locator('#dialogue').is_visible())
        self.page.get_by_role('button', name='Como posso ajudar?', exact=True).click()
        self.assertEqual(self.page.evaluate('rpg.quest'), 1)
        self.assertTrue(self.page.get_by_role('button', name='Entregar componentes', exact=False).is_disabled())
        self.page.keyboard.press('Escape')
        self.page.evaluate('inv.scrap=6;inv.cloth=2')
        self.page.wait_for_function("tgt && tgt.k==='trader'")
        self.page.keyboard.press('KeyE')
        self.page.get_by_role('button', name='Entregar componentes', exact=False).click()
        self.assertEqual(self.page.evaluate('[rpg.quest,inv.scrap,inv.cloth]'), [2,0,0])
        self.page.keyboard.press('Escape')
        self.page.evaluate('P.x=RELAY.x;P.z=RELAY.z+2')
        self.page.wait_for_function("tgt && tgt.k==='relay'")
        self.page.keyboard.press('KeyE')
        self.assertEqual(self.page.evaluate('rpg.quest'), 3)
        self.assertEqual(self.page.evaluate('En.filter(e=>e.signalGuard&&!e.dead).length'), 3)
        self.page.keyboard.press('Escape')
        self.page.reload(wait_until='networkidle')
        self.page.get_by_role('button', name='Continuar expedição', exact=True).click()
        self.assertEqual(self.page.evaluate('rpg.quest'), 3)
        self.assertEqual(self.page.evaluate('En.filter(e=>e.signalGuard&&!e.dead).length'), 3)
        self.page.evaluate('for(const e of En.filter(e=>e.signalGuard&&!e.dead))kill(e);P.x=TRD.x;P.z=TRD.z+2')
        self.page.wait_for_function("tgt && tgt.k==='trader'")
        self.page.keyboard.press('KeyE')
        caps=self.page.evaluate('inv.caps')
        self.page.get_by_role('button', name='Receber recompensa', exact=False).click()
        self.assertEqual(self.page.evaluate('rpg.quest'), 5)
        self.assertEqual(self.page.evaluate('inv.caps'), caps+80)
        self.assertEqual(self.page.get_by_role('button', name='Receber recompensa', exact=False).count(), 0)
        self.assertEqual(self.errors, [])
