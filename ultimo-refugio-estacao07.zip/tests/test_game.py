"""Browser regression checks. Run: python3 -m unittest discover -s tests -v.

Requires the local server from /workspace/cloud-setup/3fer/serve.py.
"""
import unittest
from playwright.sync_api import sync_playwright


class GameTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p = sync_playwright().start()
        cls.browser = cls.p.chromium.launch(executable_path='/usr/bin/chromium',
            args=['--no-sandbox', '--enable-unsafe-swiftshader', '--use-angle=swiftshader'])

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.p.stop()

    def setUp(self):
        self.context = self.browser.new_context(viewport={'width': 1280, 'height': 800})
        self.page = self.context.new_page()
        self.errors = []
        self.page.on('pageerror', lambda e: self.errors.append(str(e)))
        self.page.goto('http://127.0.0.1:8000/', wait_until='networkidle')
        self.page.wait_for_function('typeof THREE !== "undefined" && R.info.render.calls > 0')

    def tearDown(self):
        self.context.close()

    def start_game(self):
        self.assertEqual(self.page.get_by_role('button', name='Nova expedição', exact=True).count(), 1,
                         'The welcome screen must offer a new expedition')
        self.page.get_by_role('button', name='Nova expedição', exact=True).click()
        self.page.wait_for_function('started && !over')

    def test_pause_freezes_simulation_and_blocks_actions(self):
        self.start_game()
        self.page.keyboard.press('Escape')
        self.page.wait_for_function('paused')
        before = self.page.evaluate('({x:P.x,z:P.z,f:nd.f,t:tod,ammo:mag[weapon]})')
        self.page.keyboard.down('KeyW')
        self.page.keyboard.press('KeyG')
        self.page.keyboard.press('KeyT')
        self.page.wait_for_timeout(500)
        self.page.keyboard.up('KeyW')
        self.assertEqual(before, self.page.evaluate('({x:P.x,z:P.z,f:nd.f,t:tod,ammo:mag[weapon]})'))
        self.page.get_by_role('button', name='Voltar ao jogo', exact=True).click()
        self.page.wait_for_function('!paused')
        self.page.keyboard.down('KeyW')
        self.page.wait_for_function('z=>P.z !== z',arg=before['z'])
        self.page.keyboard.up('KeyW')
        self.assertNotEqual(before['z'], self.page.evaluate('P.z'))
        self.assertEqual(self.errors, [])

    def test_checkpoint_restores_progress_and_new_game_clears_it(self):
        self.start_game()
        self.page.evaluate('inv.scrap=17; dayN=3; lvl=2; xp=35; mods[10]=1; WP[1].mag=18; mag[1]=16; buildBed(); yaw=1; buildWall(); buildTurret()')
        buildings = self.page.evaluate('built.map(b=>({kind:b.kind,x:b.w.x,z:b.w.z}))')
        self.page.keyboard.press('Escape')
        self.page.get_by_role('button', name='Salvar no acampamento', exact=True).click()
        self.page.reload(wait_until='networkidle')
        self.page.get_by_role('button', name='Continuar expedição', exact=True).click()
        self.page.wait_for_function('started && !paused')
        self.assertEqual(self.page.evaluate('[inv.scrap,dayN,lvl,xp,mag[1],WP[1].mag]'), [17,3,2,35,16,18])
        self.assertEqual(self.page.evaluate('built.map(b=>({kind:b.kind,x:b.w.x,z:b.w.z}))'), buildings)
        self.assertEqual(self.page.evaluate('tur.length'), 1)
        self.page.keyboard.press('Escape')
        self.page.reload(wait_until='networkidle')
        self.page.get_by_role('button', name='Nova expedição', exact=True).click()
        self.assertEqual(self.page.evaluate('[inv.scrap,dayN,lvl]'), [2,1,1])
        self.assertEqual(self.errors, [])

    def test_automatic_checkpoint_survives_reload(self):
        self.start_game()
        self.page.evaluate('inv.caps=47; saveTimer=30')
        self.page.wait_for_function("localStorage.getItem('ultimo-refugio-checkpoint-v1') !== null")
        self.page.reload(wait_until='networkidle')
        self.page.get_by_role('button', name='Continuar expedição', exact=True).click()
        self.assertEqual(self.page.evaluate('inv.caps'), 47)
        self.assertEqual(self.errors, [])

    def test_corrupt_save_does_not_break_new_game(self):
        self.page.evaluate("localStorage.setItem('ultimo-refugio-checkpoint-v1','{broken')")
        self.page.reload(wait_until='networkidle')
        self.assertTrue(self.page.get_by_role('button', name='Continuar expedição', exact=True).is_disabled())
        self.start_game()
        self.assertEqual(self.errors, [])

    def test_invalid_mission_in_checkpoint_is_rejected(self):
        self.start_game()
        self.page.keyboard.press('Escape')
        self.context.add_init_script("""
            const key='ultimo-refugio-checkpoint-v1';
            const checkpoint=JSON.parse(localStorage.getItem(key));
            if(checkpoint){checkpoint.mission=0.5;localStorage.setItem(key,JSON.stringify(checkpoint))}
        """)
        self.page.reload(wait_until='networkidle')
        self.assertTrue(self.page.get_by_role('button', name='Continuar expedição', exact=True).is_disabled())
        self.assertEqual(self.errors, [])

    def test_crafting_does_not_shoot_and_blur_pauses(self):
        self.start_game()
        self.page.keyboard.press('KeyC')
        self.page.wait_for_function('menu')
        ammo = self.page.evaluate('mag[weapon]')
        self.page.locator('#menu h3').click()
        self.assertEqual(self.page.evaluate('mag[weapon]'), ammo)
        self.page.keyboard.press('Escape')
        self.page.wait_for_function('!menu')
        self.page.evaluate("dispatchEvent(new Event('blur'))")
        self.page.wait_for_function('paused')
        self.assertEqual(self.errors, [])


if __name__ == '__main__':
    unittest.main()
