# Último Refúgio — expansão de RPG

Objetivo: aproximar a experiência de um RPG retrofuturista de deserto com identidade própria, mantendo o HTML portátil. O usuário delegou as escolhas e pediu execução direta.

## Entregas, em ordem

1. Terminal de pulso em verde CRT (I): estado, suprimentos/armas utilizáveis, missões, mapa com destino, rádio e qualidade gráfica. Um único estado modal impede movimento, tiro e consumo de tempo durante menus. Checkpoint compatível com a versão anterior.
2. Combate assistido (Tab): seleção de inimigo e cabeça/tronco/pernas, chance baseada em distância e cobertura, custo de 25 PA por disparo, tempo a 8%, recuperação de PA fora do modo. Acertos em pernas reduzem velocidade; tiro não atravessa paredes. Pausa e foco da janela têm precedência.
3. Iara: diálogo ramificado, comércio, missão de reparar rádio (6 sucatas/2 panos), ativar transmissão e enfrentar 3 invasores, voltar para recompensa única. Estado de missão salvo e onda incompleta recriada ao carregar.
4. Estação 07: bombas de combustível, abrigo aberto, placa, antena e torre d'água procedurais; materiais metálicos, estrada e sinalização; pós-processamento com suavização, glow, granulação, cor e vinheta. Qualidade selecionável e modo sem efeitos.
5. Testes reais no Chromium: regressões atuais mais terminal, mapa, PA/munição, cobertura, diálogo/recompensa única, retomada de missão, renderer e captura de telas.

## Limites e validação

Sem cópia de assets ou áudio de jogos comerciais, sem serviço pago ou credenciais necessários. Sons sintetizados localmente. Teclado/mouse e WebGL. Não publicar ou fazer push. Usar o checkout isolado existente. Origem remota ainda sem commits.

Riscos a verificar: fechamento de modal com pointerlock; save antigo/inválido; morte em câmera lenta; onda incompleta após reload; uso repetido de recompensa; render target após resize; botões não dispararem a arma.

Comando final: `python3 -m unittest discover -s tests -v`, mais smoke original e screenshots. Servidor de teste: /workspace/cloud-setup/3fer/serve.py.
