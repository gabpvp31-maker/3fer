// Precomputed from design/form-audit.json and room-layout.json.
// Blender (x,y,z) becomes Three (x,z,-y); front wall split at the doorway.
export const COLLIDERS = [
  {
    "x": 0.0,
    "z": -10.0,
    "hx": 12.0,
    "hz": 0.15,
    "yaw": 0
  },
  {
    "x": -12.0,
    "z": -0.0,
    "hx": 0.15,
    "hz": 10.0,
    "yaw": 0
  },
  {
    "x": 12.0,
    "z": -0.0,
    "hx": 0.15,
    "hz": 10.0,
    "yaw": 0
  },
  {
    "x": 6.9,
    "z": -9.1,
    "hx": 4.1,
    "hz": 0.175,
    "yaw": 0
  },
  {
    "x": 2.9,
    "z": -5.6,
    "hx": 0.175,
    "hz": 3.675,
    "yaw": 0
  },
  {
    "x": 10.9,
    "z": -5.6,
    "hx": 0.175,
    "hz": 3.675,
    "yaw": 0
  },
  {
    "x": 6.8,
    "z": -8.25,
    "hx": 1.5,
    "hz": 0.425,
    "yaw": 0
  },
  {
    "x": 10.35,
    "z": -4.2,
    "hx": 0.35,
    "hz": 0.75,
    "yaw": 0
  },
  {
    "x": 10.35,
    "z": -6.0,
    "hx": 0.35,
    "hz": 0.75,
    "yaw": 0
  },
  {
    "x": -6.3,
    "z": -5.7,
    "hx": 0.48,
    "hz": 0.48,
    "yaw": 0
  },
  {
    "x": -8.5,
    "z": -6.8,
    "hx": 0.36,
    "hz": 0.36,
    "yaw": 0
  },
  {
    "x": -8.0,
    "z": -7.5,
    "hx": 0.36,
    "hz": 0.36,
    "yaw": 0
  },
  {
    "x": 9.0,
    "z": 1.0,
    "hx": 0.36,
    "hz": 0.36,
    "yaw": 0
  },
  {
    "x": -9.35233,
    "z": -7.51119,
    "hx": 0.27753,
    "hz": 0.22367,
    "yaw": 0
  },
  {
    "x": -9.92501,
    "z": -7.9071,
    "hx": 0.14032,
    "hz": 0.15425,
    "yaw": 0
  },
  {
    "x": -8.74513,
    "z": -8.62679,
    "hx": 0.24558,
    "hz": 0.25258,
    "yaw": 0
  },
  {
    "x": -9.71149,
    "z": -7.46491,
    "hx": 0.18447,
    "hz": 0.27457,
    "yaw": 0
  },
  {
    "x": -8.90451,
    "z": -7.3879,
    "hx": 0.14417,
    "hz": 0.16679,
    "yaw": 0
  },
  {
    "x": -9.09363,
    "z": -7.71967,
    "hx": 0.23168,
    "hz": 0.31622,
    "yaw": 0
  },
  {
    "x": -8.54111,
    "z": -7.70311,
    "hx": 0.37432,
    "hz": 0.26101,
    "yaw": 0
  },
  {
    "x": -9.92159,
    "z": 5.7645,
    "hx": 0.27399,
    "hz": 0.28609,
    "yaw": 0
  },
  {
    "x": -8.84021,
    "z": 6.06131,
    "hx": 0.30134,
    "hz": 0.34357,
    "yaw": 0
  },
  {
    "x": -8.70574,
    "z": 5.30967,
    "hx": 0.33232,
    "hz": 0.25227,
    "yaw": 0
  },
  {
    "x": -9.6639,
    "z": 6.53607,
    "hx": 0.24733,
    "hz": 0.24023,
    "yaw": 0
  },
  {
    "x": -9.83884,
    "z": 6.07114,
    "hx": 0.27879,
    "hz": 0.27344,
    "yaw": 0
  },
  {
    "x": -9.28246,
    "z": 5.46213,
    "hx": 0.35229,
    "hz": 0.24772,
    "yaw": 0
  },
  {
    "x": -8.82175,
    "z": 6.33215,
    "hx": 0.12585,
    "hz": 0.22907,
    "yaw": 0
  },
  {
    "x": 9.03098,
    "z": 5.83537,
    "hx": 0.21968,
    "hz": 0.21239,
    "yaw": 0
  },
  {
    "x": 8.78476,
    "z": 6.14143,
    "hx": 0.14345,
    "hz": 0.2734,
    "yaw": 0
  },
  {
    "x": 8.68011,
    "z": 6.62639,
    "hx": 0.16475,
    "hz": 0.14517,
    "yaw": 0
  },
  {
    "x": 9.22814,
    "z": 6.49203,
    "hx": 0.22341,
    "hz": 0.20192,
    "yaw": 0
  },
  {
    "x": 8.93198,
    "z": 6.02263,
    "hx": 0.13546,
    "hz": 0.17405,
    "yaw": 0
  },
  {
    "x": 8.04619,
    "z": 5.36862,
    "hx": 0.21002,
    "hz": 0.21841,
    "yaw": 0
  },
  {
    "x": 9.72665,
    "z": 5.72532,
    "hx": 0.15325,
    "hz": 0.2072,
    "yaw": 0
  },
  {
    "x": -0.34067,
    "z": -7.61226,
    "hx": 0.25287,
    "hz": 0.32738,
    "yaw": 0
  },
  {
    "x": -0.54652,
    "z": -8.02469,
    "hx": 0.17482,
    "hz": 0.18544,
    "yaw": 0
  },
  {
    "x": 0.91303,
    "z": -7.92612,
    "hx": 0.39182,
    "hz": 0.31654,
    "yaw": 0
  },
  {
    "x": -0.60659,
    "z": -7.58612,
    "hx": 0.25513,
    "hz": 0.32066,
    "yaw": 0
  },
  {
    "x": -0.83044,
    "z": -8.22482,
    "hx": 0.29776,
    "hz": 0.35693,
    "yaw": 0
  },
  {
    "x": -0.33497,
    "z": -8.42115,
    "hx": 0.3252,
    "hz": 0.18474,
    "yaw": 0
  },
  {
    "x": -0.74592,
    "z": -7.51161,
    "hx": 0.21207,
    "hz": 0.30338,
    "yaw": 0
  },
  {
    "x": -7,
    "z": 10,
    "hx": 5,
    "hz": 0.15,
    "yaw": 0
  },
  {
    "x": 7,
    "z": 10,
    "hx": 5,
    "hz": 0.15,
    "yaw": 0
  },
  {
    "x": 4.1125,
    "z": -2,
    "hx": 1.3875,
    "hz": 0.2,
    "yaw": 0
  },
  {
    "x": 9.8875,
    "z": -2,
    "hx": 1.1875,
    "hz": 0.2,
    "yaw": 0
  },
  {
    "x": -4,
    "z": 0.5,
    "hx": 1.1,
    "hz": 2.35,
    "yaw": -0.45
  }
];

// Cache rotation and conservative broad-phase extents outside the frame loop.
const prepared = new WeakMap();
function prepare(colliders) {
 let result = prepared.get(colliders);
 if (!result) {
  result = colliders.map(box => {
   const c = Math.cos(box.yaw || 0), s = Math.sin(box.yaw || 0);
   return {...box,c,s,ex:Math.abs(c)*box.hx+Math.abs(s)*box.hz,
    ez:Math.abs(s)*box.hx+Math.abs(c)*box.hz};
  });
  prepared.set(colliders,result);
 }
 return result;
}

export function movePlayer(pos, delta, colliders = COLLIDERS, radius = .28) {
 let x = pos.x, z = pos.z;
 const boxes = prepare(colliders);
 // A step shorter than the body radius cannot jump through even a thin wall.
 const steps = Math.max(1, Math.ceil(Math.hypot(delta.x,delta.z)/Math.min(.1,radius*.5)));
 const dx = delta.x/steps, dz = delta.z/steps;
 for (let step=0; step<steps; step++) {
  x += dx; z += dz;
  // Two passes also resolve corners where neighboring bounds overlap.
  for (let pass=0; pass<2; pass++) for (const b of boxes) {
   const ox=x-b.x, oz=z-b.z;
   if(Math.abs(ox)>b.ex+radius || Math.abs(oz)>b.ez+radius) continue;
   let lx=b.c*ox-b.s*oz, lz=b.s*ox+b.c*oz;
   const cx=Math.max(-b.hx,Math.min(b.hx,lx));
   const cz=Math.max(-b.hz,Math.min(b.hz,lz));
   const vx=lx-cx, vz=lz-cz, distance=Math.hypot(vx,vz);
   if(distance>=radius) continue;
   if(distance>1e-9) {
    const push=(radius-distance)/distance;
    lx+=vx*push; lz+=vz*push;
   } else {
    const px=b.hx-Math.abs(lx), pz=b.hz-Math.abs(lz);
    if(px<pz) lx=(lx<0?-1:1)*(b.hx+radius);
    else lz=(lz<0?-1:1)*(b.hz+radius);
   }
   x=b.x+b.c*lx+b.s*lz;
   z=b.z-b.s*lx+b.c*lz;
  }
 }
 return {x,z};
}

export function groundHeight(x,z) {
 return x>=2.8 && x<=11 && z>=-9.3 && z<=-1.9 ? .16 : 0;
}

// Runtime returns to the title immediately here, before reaching the floor edge.
export function isExit(x,z) { return z>9.8 && Math.abs(x)<1.7; }
