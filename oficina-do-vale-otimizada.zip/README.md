# Oficina do Vale

Mapa compacto de 24 × 20 metros criado no Blender: pátio industrial, garagem acessível, cupê abandonado, bomba retrô e bancada de rádio. Arte original retrofuturista; equivalência gráfica com Fallout 4 não foi demonstrada.

## Jogar

Sirva esta pasta com um servidor HTTP estático, por exemplo:

```sh
cd /workspace/3fer
python3 -m http.server 8000 --bind 127.0.0.1
```

Abra o endereço local da porta 8000 no navegador. Clique em **Explorar mapa**. Use WASD para andar, Shift para correr, mouse ou setas para olhar e Esc para pausar. F3 mostra diagnósticos. A saída do pátio retorna ao menu. Não há combate nesta versão.

## Otimização e verificação

- 119.886 → 62.654 triângulos; 678 objetos de origem → 17 lotes espaciais.
- Iluminação pré-calculada no Cycles; duas texturas residentes, sem sombras dinâmicas.
- Modos Automático, Leve, Equilibrado e Detalhado; texturas carregadas conforme a qualidade escolhida.
- Sem renderização contínua quando pausado; física com passo fixo e colisões locais.
- GLB de 1,52 MB; modelo e texturas do modo leve somam 1.84 MB, além do código e biblioteca local.
- 14 testes Python e 8 testes Node passaram. Em Chromium com SwiftShader (renderização por software), modo leve: 25,6 FPS em janela de 1280 × 720, resolução interna 896 × 503. Desempenho com GPU física não foi medido. Equilibrado e Detalhado ficaram próximos de 13 FPS nesse ambiente.
- Nenhum erro de JavaScript ou requisição externa observado no perfil. Dependências de execução estão em `vendor/`.

Resultados e capturas reais do navegador: `design/runtime/`. Exportação: `assets/runtime-manifest.json`. Fonte Blender aprovada preservada: `design/oficina-do-vale.blend`. O exportador verifica os hashes de aprovação antes de reconstruir os assets.

## Reproduzir e testar

Requer Blender 4.3.2 para autoria/exportação, Python 3 e Node para testes; Playwright e Chromium para testes de navegador. O Blender disponível usa Cycles CPU sem OpenImageDenoise.

```sh
python3 -m unittest discover -s tests -v
node tests/physics.test.mjs
# Com o servidor ativo e Playwright/Chromium instalados:
RUNTIME_BROWSER=1 python3 -m unittest discover -s tests -v
python3 scripts/profile_runtime.py
# Reconstrução cara: refaz os bakes de iluminação aprovados.
blender -b -t 4 --python-exit-code 1 --python blender/export_optimized_runtime.py
```

A receita de autoria está em `scripts/build_form_source.sh` e `design/FORM-PLAN.md`. A exportação otimizada preserva a fonte de autoria.

## Estado e preservação

Function e Form aprovados pelo usuário; exportação e otimização autorizadas. Runtime testado, com aprovação de publicação ainda pendente. Nenhuma alteração desta reformulação foi enviada ao GitHub ou publicada. O ZIP antigo foi removido apenas da cópia local.

Backup integral anterior: `/workspace/backups/3fer-before-blender-map-20261103T233701Z.tar.gz`. Aprovações registradas em `design/milestone-reviews.json`.
