# Comparação com a captura do posto original

Referência: `references/red-rocket-sanctuary-gameplay.webp`, captura de gameplay publicada na wiki de Fallout. Fonte e hash em `references/primary-reference.json`. A imagem Pinterest identificada como fanart UE5 não controla a reconstrução.

Correções executadas no novo estudo nativo:

| Elemento observado | Alteração realizada |
| --- | --- |
| Foguete vermelho quase vertical com pods externos | Corpo vermelho, três pods, webs e hastes; inclinação medida de 8,30° em relação à vertical. |
| Apoios diagonais perfurados | Quatro pernas de A-frame, com dezesseis furos aplicados por Boolean e testados por raios contra a geometria avaliada. |
| Cobertura estreita com faixa vermelha e bordas metálicas | Cobertura contínua conectada ao edifício, com bordas prateadas, juntas e faixa vermelha. |
| Letreiro sobre a oficina | Letras vermelhas maiores, contornos metálicos e faces danificadas, acima da garagem. |
| Entrada vermelha e pequena marquise curva | Nova abertura estrutural de 1,30 m, porta aberta e marquise curva; fachada de alvenaria com perfis metálicos. |
| Dispensadores suspensos | Três unidades vermelhas sob o teto, montagens superiores, mangueiras e bocais. |
| Painel de coolant e máquina vermelha | Novos volumes curvos completos com seus apoios e detalhes frontais. |
| Veículos e vegetação seca | Dois cupês curvos autorais do projeto reutilizados e tufos secos no pátio. Os carros não reproduzem os modelos exatos de Fallout. |

Auditoria: `reference-geometry-audit.json`. Perspectiva, plantas e estudos dos oito objetos: `study-render-manifest.json`. A câmera inicial está a 1,70 m, dentro do domínio, e enquadra integralmente foguete, painel, letreiro e veículo em primeiro plano. O teste de remoção de um apoio rejeita a cena alterada.

Limites: uma perspectiva não estabelece medidas exatas, a parte posterior do posto nem o interior completo. Materiais e contexto permanecem em etapa de estudo. Fonte e evidências corrigidas aguardam revisão Function; Form e Runtime continuam pendentes. Novo mapa não exportado, ZIP funcional anterior intacto, nada enviado ou publicado.

## Refinamento adicional

Ver `similarity-refinement-review.json`: os apoios agora têm perfil curvo e maior largura; a cobertura está mais inclinada à esquerda e tem vegetação pendurada; tintas, tijolos, equipamento da fachada, carro aberto e pátio foram revistos. A nova vista `renders/reference-framing.png` aproxima o ângulo da referência, separada da câmera inicial auditada. As métricas atuais são as desse relatório e do manifesto de treze capturas.

## Veículo e proporções atuais

A revisão mais recente está em `vehicle-proportions-review.json`: o cupê da frente foi substituído por carroceria vintage autoral com cockpit oval, molduras quebradas, arcos reais e para-choques cromados; foi reposicionado para o primeiro plano. O foguete tem suportes 1,05 m mais longos e a garagem tem painéis superiores metálicos mais próximos da captura. As formas não vistas continuam estimadas.
