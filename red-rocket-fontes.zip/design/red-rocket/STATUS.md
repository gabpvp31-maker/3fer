# Red Rocket — exportação jogável

O usuário pediu texturas mais próximas da direção visual de Fallout 4 e, depois, autorizou explicitamente: “então exporta”. A autorização dessa exportação está em `export-authorization.json`, vinculada ao hash da fonte atual. As aprovações individuais anteriores continuam registradas como pendentes; não foram inventadas aprovações de imagens ou de publicação.

Fonte nativa: `layout-study.blend`, com 301.370 triângulos e 3.967 objetos. Oito materiais recebem fotografias CC0 de Poly Haven e ambientCG; fontes e licenças em `materials/sources.json`. Não são texturas extraídas de Fallout. O modelo é autoral, guiado por uma captura; dimensões e partes não mostradas são estimadas.

Runtime: 102.585 triângulos em 26 lotes, mais o céu. GLB e texturas do modo leve somam 7.844.281 bytes. As fotografias conservam escala métrica, com UVs por face. Oclusão é pré-calculada nos vértices; não há passes de sombra dinâmica. O modo Detalhado acrescenta rugosidade e relevo. Não confundir a contagem nativa com a geometria carregada no navegador.

Código modular: `red-rocket/` na raiz do projeto. HTML offline gerado por `red-rocket/scripts/build_portable.py`. Capturas reais e relatório de navegador em `runtime/`; `renders/` e `images/` são evidências de autoria no Blender.

Verificações: 15 testes Python passaram e dois testes antigos de navegador ficaram desabilitados; sete testes de colisão do Red Rocket e oito do mapa antigo passaram. A verificação dedicada do Red Rocket passou: carregamento, movimento, pausa, três modos de qualidade, recuperação de falha de carregamento e troca de qualidade, e HTML offline em origem opaca sem requisições externas. Relatório: `runtime/browser-report.json`. O ambiente bloqueia navegação direta file://, por isso o teste offline usou iframe isolado sem permissão de mesma origem. O carregamento offline demorou 8,8 s. O modo Leve passou de 7,7 para 19,5 FPS no SwiftShader (software), a 640 × 400 pixels internos; Equilibrado e Detalhado ficaram abaixo de 4 FPS nesse renderizador. A meta de 30 FPS não foi demonstrada nessa configuração. Não há medição em GPU física.

A fonte nativa e o ZIP antigo da Oficina do Vale foram preservados. Nenhuma implantação do jogo ou publicação do ambiente está autorizada nesta etapa. Os ZIPs de entrega são arquivos de download em branch separada.
