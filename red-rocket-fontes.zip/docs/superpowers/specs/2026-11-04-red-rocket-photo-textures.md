# Texturas fotográficas do Red Rocket

O usuário especificou: “as texturas deixa parecido com as de fallout 4”. A revisão aplica materiais CC0 fotográficos de Poly Haven e ambientCG, com fontes e hashes em `design/red-rocket/materials/sources.json`. Não são texturas extraídas de Fallout.

O módulo `blender/red_rocket_pbr.py` liga mapas de cor, rugosidade e altura aos materiais de pintura vermelha, pintura azul, alumínio oxidado, ferro oxidado, tijolos, concreto e asfalto. Pintura é recolorida sobre o padrão fotográfico de ferrugem. Cor usa sRGB; dados de rugosidade e relevo usam Non-Color. Projeção box triplanar usa coordenadas em metros para evitar esticar a fotografia pelo edifício inteiro. Concreto e tijolo usam dimensões fornecidas pelo ambientCG; a escala dos dois materiais Poly Haven é estimada e declarada. Mapas de altura produzem bump sem acrescentar polígonos. Mapas normais foram preservados como fontes, mas não são ligados incorretamente em espaço tangente em malhas sem UV apropriado.

As fontes de autoria têm até 1K, são incorporadas ao arquivo .blend e ficam separadas do jogo existente. A auditoria verifica o caminho das imagens até os sockets reais do shader, os espaços de cor e a incorporação. Desligar a cor fotográfica deve fazer a auditoria falhar.

A revisão ampla iniciada antes dessa especificação também acrescenta perfil metálico dobrado da cobertura, placas de concreto lascadas, vegetação baixa em malhas agrupadas e árvores secas no entorno. A estrutura principal e a câmera inicial permanecem preservadas. A vista `renders/material-closeup.png` serve à revisão das texturas no Blender; não é captura do runtime.

O novo mapa continua sem exportação para runtime ou publicação; a meta de otimização do futuro jogo permanece pendente de validação própria. Aprovações não são inferidas de renders ou testes.
